---
title: "Machine Learning Project"
author: "Renata GPPR"
date: "5/1/2020"
output: 
  pdf_document:
    highlight: tango
    
    
---



# **Machine Learning with Cereal!** 

This is my final project for the R class, in which I chose a cereal data set from [Kaggle](https://www.kaggle.com/crawford/80-cereals) to test two different machine learning algorithms. 

## Importing Data & Cleaning 




## Data Analysis 

My dataset is composed of 77 types of cereal, their nutrition facts, and their overall rating. 
I am using the rating variable as my DV and all other variables relating to nutrition as predictors of that rating.



## Model 1 Random Forest 

```r
model1 <- train(
  rating~., 
  data = Data, 
  method = "ranger", tuneLength = 5, trControl = train.control)  
```

```
## + Fold1: mtry= 2, min.node.size=5, splitrule=variance 
## - Fold1: mtry= 2, min.node.size=5, splitrule=variance 
## + Fold1: mtry=25, min.node.size=5, splitrule=variance 
## - Fold1: mtry=25, min.node.size=5, splitrule=variance 
## + Fold1: mtry=49, min.node.size=5, splitrule=variance 
## - Fold1: mtry=49, min.node.size=5, splitrule=variance 
## + Fold1: mtry=72, min.node.size=5, splitrule=variance 
## - Fold1: mtry=72, min.node.size=5, splitrule=variance 
## + Fold1: mtry=96, min.node.size=5, splitrule=variance 
## - Fold1: mtry=96, min.node.size=5, splitrule=variance 
## + Fold1: mtry= 2, min.node.size=5, splitrule=extratrees 
## - Fold1: mtry= 2, min.node.size=5, splitrule=extratrees 
## + Fold1: mtry=25, min.node.size=5, splitrule=extratrees 
## - Fold1: mtry=25, min.node.size=5, splitrule=extratrees 
## + Fold1: mtry=49, min.node.size=5, splitrule=extratrees 
## - Fold1: mtry=49, min.node.size=5, splitrule=extratrees 
## + Fold1: mtry=72, min.node.size=5, splitrule=extratrees 
## - Fold1: mtry=72, min.node.size=5, splitrule=extratrees 
## + Fold1: mtry=96, min.node.size=5, splitrule=extratrees 
## - Fold1: mtry=96, min.node.size=5, splitrule=extratrees 
## + Fold2: mtry= 2, min.node.size=5, splitrule=variance 
## - Fold2: mtry= 2, min.node.size=5, splitrule=variance 
## + Fold2: mtry=25, min.node.size=5, splitrule=variance 
## - Fold2: mtry=25, min.node.size=5, splitrule=variance 
## + Fold2: mtry=49, min.node.size=5, splitrule=variance 
## - Fold2: mtry=49, min.node.size=5, splitrule=variance 
## + Fold2: mtry=72, min.node.size=5, splitrule=variance 
## - Fold2: mtry=72, min.node.size=5, splitrule=variance 
## + Fold2: mtry=96, min.node.size=5, splitrule=variance 
## - Fold2: mtry=96, min.node.size=5, splitrule=variance 
## + Fold2: mtry= 2, min.node.size=5, splitrule=extratrees 
## - Fold2: mtry= 2, min.node.size=5, splitrule=extratrees 
## + Fold2: mtry=25, min.node.size=5, splitrule=extratrees 
## - Fold2: mtry=25, min.node.size=5, splitrule=extratrees 
## + Fold2: mtry=49, min.node.size=5, splitrule=extratrees 
## - Fold2: mtry=49, min.node.size=5, splitrule=extratrees 
## + Fold2: mtry=72, min.node.size=5, splitrule=extratrees 
## - Fold2: mtry=72, min.node.size=5, splitrule=extratrees 
## + Fold2: mtry=96, min.node.size=5, splitrule=extratrees 
## - Fold2: mtry=96, min.node.size=5, splitrule=extratrees 
## + Fold3: mtry= 2, min.node.size=5, splitrule=variance 
## - Fold3: mtry= 2, min.node.size=5, splitrule=variance 
## + Fold3: mtry=25, min.node.size=5, splitrule=variance 
## - Fold3: mtry=25, min.node.size=5, splitrule=variance 
## + Fold3: mtry=49, min.node.size=5, splitrule=variance 
## - Fold3: mtry=49, min.node.size=5, splitrule=variance 
## + Fold3: mtry=72, min.node.size=5, splitrule=variance 
## - Fold3: mtry=72, min.node.size=5, splitrule=variance 
## + Fold3: mtry=96, min.node.size=5, splitrule=variance 
## - Fold3: mtry=96, min.node.size=5, splitrule=variance 
## + Fold3: mtry= 2, min.node.size=5, splitrule=extratrees 
## - Fold3: mtry= 2, min.node.size=5, splitrule=extratrees 
## + Fold3: mtry=25, min.node.size=5, splitrule=extratrees 
## - Fold3: mtry=25, min.node.size=5, splitrule=extratrees 
## + Fold3: mtry=49, min.node.size=5, splitrule=extratrees 
## - Fold3: mtry=49, min.node.size=5, splitrule=extratrees 
## + Fold3: mtry=72, min.node.size=5, splitrule=extratrees 
## - Fold3: mtry=72, min.node.size=5, splitrule=extratrees 
## + Fold3: mtry=96, min.node.size=5, splitrule=extratrees 
## - Fold3: mtry=96, min.node.size=5, splitrule=extratrees 
## + Fold4: mtry= 2, min.node.size=5, splitrule=variance 
## - Fold4: mtry= 2, min.node.size=5, splitrule=variance 
## + Fold4: mtry=25, min.node.size=5, splitrule=variance 
## - Fold4: mtry=25, min.node.size=5, splitrule=variance 
## + Fold4: mtry=49, min.node.size=5, splitrule=variance 
## - Fold4: mtry=49, min.node.size=5, splitrule=variance 
## + Fold4: mtry=72, min.node.size=5, splitrule=variance 
## - Fold4: mtry=72, min.node.size=5, splitrule=variance 
## + Fold4: mtry=96, min.node.size=5, splitrule=variance 
## - Fold4: mtry=96, min.node.size=5, splitrule=variance 
## + Fold4: mtry= 2, min.node.size=5, splitrule=extratrees 
## - Fold4: mtry= 2, min.node.size=5, splitrule=extratrees 
## + Fold4: mtry=25, min.node.size=5, splitrule=extratrees 
## - Fold4: mtry=25, min.node.size=5, splitrule=extratrees 
## + Fold4: mtry=49, min.node.size=5, splitrule=extratrees 
## - Fold4: mtry=49, min.node.size=5, splitrule=extratrees 
## + Fold4: mtry=72, min.node.size=5, splitrule=extratrees 
## - Fold4: mtry=72, min.node.size=5, splitrule=extratrees 
## + Fold4: mtry=96, min.node.size=5, splitrule=extratrees 
## - Fold4: mtry=96, min.node.size=5, splitrule=extratrees 
## + Fold5: mtry= 2, min.node.size=5, splitrule=variance 
## - Fold5: mtry= 2, min.node.size=5, splitrule=variance 
## + Fold5: mtry=25, min.node.size=5, splitrule=variance 
## - Fold5: mtry=25, min.node.size=5, splitrule=variance 
## + Fold5: mtry=49, min.node.size=5, splitrule=variance 
## - Fold5: mtry=49, min.node.size=5, splitrule=variance 
## + Fold5: mtry=72, min.node.size=5, splitrule=variance 
## - Fold5: mtry=72, min.node.size=5, splitrule=variance 
## + Fold5: mtry=96, min.node.size=5, splitrule=variance 
## - Fold5: mtry=96, min.node.size=5, splitrule=variance 
## + Fold5: mtry= 2, min.node.size=5, splitrule=extratrees 
## - Fold5: mtry= 2, min.node.size=5, splitrule=extratrees 
## + Fold5: mtry=25, min.node.size=5, splitrule=extratrees 
## - Fold5: mtry=25, min.node.size=5, splitrule=extratrees 
## + Fold5: mtry=49, min.node.size=5, splitrule=extratrees 
## - Fold5: mtry=49, min.node.size=5, splitrule=extratrees 
## + Fold5: mtry=72, min.node.size=5, splitrule=extratrees 
## - Fold5: mtry=72, min.node.size=5, splitrule=extratrees 
## + Fold5: mtry=96, min.node.size=5, splitrule=extratrees 
## - Fold5: mtry=96, min.node.size=5, splitrule=extratrees 
## Aggregating results
## Selecting tuning parameters
## Fitting mtry = 96, splitrule = extratrees, min.node.size = 5 on full training set
```

```r
# Print Model
model1
```

```
## Random Forest 
## 
## 77 samples
## 15 predictors
## 
## No pre-processing
## Resampling: Cross-Validated (5 fold) 
## Summary of sample sizes: 61, 61, 63, 62, 61 
## Resampling results across tuning parameters:
## 
##   mtry  splitrule   RMSE       Rsquared   MAE     
##    2    variance    11.370764  0.8127419  8.795836
##    2    extratrees  12.204754  0.8466844  9.593928
##   25    variance     5.760278  0.8729621  4.022992
##   25    extratrees   6.192364  0.8925914  4.500576
##   49    variance     5.838461  0.8533031  4.184233
##   49    extratrees   5.773893  0.8939961  4.019297
##   72    variance     6.120110  0.8296704  4.472271
##   72    extratrees   5.772117  0.8823891  3.997493
##   96    variance     6.275765  0.8144072  4.550595
##   96    extratrees   5.631604  0.8834319  3.908986
## 
## Tuning parameter 'min.node.size' was held constant at a value of 5
## RMSE was used to select the optimal model using the smallest value.
## The final values used for the model were mtry = 96, splitrule = extratrees
##  and min.node.size = 5.
```

```r
# Summary of model
summary(model1)
```

```
##                           Length Class         Mode     
## predictions               77     -none-        numeric  
## num.trees                  1     -none-        numeric  
## num.independent.variables  1     -none-        numeric  
## mtry                       1     -none-        numeric  
## min.node.size              1     -none-        numeric  
## prediction.error           1     -none-        numeric  
## forest                     7     ranger.forest list     
## splitrule                  1     -none-        character
## num.random.splits          1     -none-        numeric  
## treetype                   1     -none-        character
## r.squared                  1     -none-        numeric  
## call                       9     -none-        call     
## importance.mode            1     -none-        character
## num.samples                1     -none-        numeric  
## replace                    1     -none-        logical  
## xNames                    96     -none-        character
## problemType                1     -none-        character
## tuneValue                  3     data.frame    list     
## obsLevels                  1     -none-        logical  
## param                      0     -none-        list
```
### Results:
RMSE was used to select the optimal model using the smallest value, RMSE =  `5.664539`, 
Rsquared = `0.8683427` and MAE =  `3.990460`.






## Model 2 GLMNET

```r
model2 <- train(
  rating~., 
  data = Data, 
  method = "glmnet", tuneLength = 5, trControl = train.control) 
```

```
## + Fold1: alpha=0.100, lambda=9.842 
## - Fold1: alpha=0.100, lambda=9.842 
## + Fold1: alpha=0.325, lambda=9.842 
## - Fold1: alpha=0.325, lambda=9.842 
## + Fold1: alpha=0.550, lambda=9.842 
## - Fold1: alpha=0.550, lambda=9.842 
## + Fold1: alpha=0.775, lambda=9.842 
## - Fold1: alpha=0.775, lambda=9.842 
## + Fold1: alpha=1.000, lambda=9.842 
## - Fold1: alpha=1.000, lambda=9.842 
## + Fold2: alpha=0.100, lambda=9.842 
## - Fold2: alpha=0.100, lambda=9.842 
## + Fold2: alpha=0.325, lambda=9.842 
## - Fold2: alpha=0.325, lambda=9.842 
## + Fold2: alpha=0.550, lambda=9.842 
## - Fold2: alpha=0.550, lambda=9.842 
## + Fold2: alpha=0.775, lambda=9.842 
## - Fold2: alpha=0.775, lambda=9.842 
## + Fold2: alpha=1.000, lambda=9.842 
## - Fold2: alpha=1.000, lambda=9.842 
## + Fold3: alpha=0.100, lambda=9.842 
## - Fold3: alpha=0.100, lambda=9.842 
## + Fold3: alpha=0.325, lambda=9.842 
## - Fold3: alpha=0.325, lambda=9.842 
## + Fold3: alpha=0.550, lambda=9.842 
## - Fold3: alpha=0.550, lambda=9.842 
## + Fold3: alpha=0.775, lambda=9.842 
## - Fold3: alpha=0.775, lambda=9.842 
## + Fold3: alpha=1.000, lambda=9.842 
## - Fold3: alpha=1.000, lambda=9.842 
## + Fold4: alpha=0.100, lambda=9.842 
## - Fold4: alpha=0.100, lambda=9.842 
## + Fold4: alpha=0.325, lambda=9.842 
## - Fold4: alpha=0.325, lambda=9.842 
## + Fold4: alpha=0.550, lambda=9.842 
## - Fold4: alpha=0.550, lambda=9.842 
## + Fold4: alpha=0.775, lambda=9.842 
## - Fold4: alpha=0.775, lambda=9.842 
## + Fold4: alpha=1.000, lambda=9.842 
## - Fold4: alpha=1.000, lambda=9.842 
## + Fold5: alpha=0.100, lambda=9.842 
## - Fold5: alpha=0.100, lambda=9.842 
## + Fold5: alpha=0.325, lambda=9.842 
## - Fold5: alpha=0.325, lambda=9.842 
## + Fold5: alpha=0.550, lambda=9.842 
## - Fold5: alpha=0.550, lambda=9.842 
## + Fold5: alpha=0.775, lambda=9.842 
## - Fold5: alpha=0.775, lambda=9.842 
## + Fold5: alpha=1.000, lambda=9.842 
## - Fold5: alpha=1.000, lambda=9.842
```

```
## Warning in nominalTrainWorkflow(x = x, y = y, wts = weights, info = trainInfo, :
## There were missing values in resampled performance measures.
```

```
## Aggregating results
## Selecting tuning parameters
## Fitting alpha = 0.325, lambda = 0.457 on full training set
```

```r
# Print Model
model2
```

```
## glmnet 
## 
## 77 samples
## 15 predictors
## 
## No pre-processing
## Resampling: Cross-Validated (5 fold) 
## Summary of sample sizes: 61, 62, 61, 62, 62 
## Resampling results across tuning parameters:
## 
##   alpha  lambda     RMSE       Rsquared   MAE      
##   0.100  0.4568197   3.234631  0.9678562   2.360523
##   0.100  0.9841883   3.239408  0.9678461   2.364083
##   0.100  2.1203695   3.591439  0.9651264   2.626706
##   0.100  4.5681977   4.337282  0.9594558   3.215022
##   0.100  9.8418838   5.746662  0.9521539   4.371267
##   0.325  0.4568197   1.952082  0.9848805   1.373753
##   0.325  0.9841883   2.454256  0.9799619   1.695221
##   0.325  2.1203695   3.619688  0.9670202   2.568812
##   0.325  4.5681977   5.201430  0.9534391   3.806493
##   0.325  9.8418838   8.152845  0.8964512   6.134660
##   0.550  0.4568197   2.074811  0.9798046   1.431280
##   0.550  0.9841883   2.890980  0.9729245   1.998729
##   0.550  2.1203695   4.185996  0.9618142   3.000613
##   0.550  4.5681977   6.516530  0.9157360   4.841969
##   0.550  9.8418838  10.003305  0.8158889   7.673284
##   0.775  0.4568197   2.353062  0.9747264   1.623405
##   0.775  0.9841883   3.274971  0.9687696   2.333347
##   0.775  2.1203695   4.769385  0.9499972   3.526767
##   0.775  4.5681977   7.581952  0.8706831   5.703377
##   0.775  9.8418838  11.812065  0.6748220   9.217488
##   1.000  0.4568197   2.568119  0.9727929   1.809964
##   1.000  0.9841883   3.551195  0.9643542   2.607967
##   1.000  2.1203695   5.351082  0.9325942   4.056257
##   1.000  4.5681977   8.468163  0.8361280   6.433982
##   1.000  9.8418838  13.230421  0.5079775  10.513775
## 
## RMSE was used to select the optimal model using the smallest value.
## The final values used for the model were alpha = 0.325 and lambda = 0.4568197.
```

```r
# Summary of model
summary(model2)
```

```
##             Length Class      Mode     
## a0           100   -none-     numeric  
## beta        9600   dgCMatrix  S4       
## df           100   -none-     numeric  
## dim            2   -none-     numeric  
## lambda       100   -none-     numeric  
## dev.ratio    100   -none-     numeric  
## nulldev        1   -none-     numeric  
## npasses        1   -none-     numeric  
## jerr           1   -none-     numeric  
## offset         1   -none-     logical  
## call           5   -none-     call     
## nobs           1   -none-     numeric  
## lambdaOpt      1   -none-     numeric  
## xNames        96   -none-     character
## problemType    1   -none-     character
## tuneValue      2   data.frame list     
## obsLevels      1   -none-     logical  
## param          0   -none-     list
```
### Results:
 RMSE was used to select the optimal model using the smallest value. The final values used for the model were alpha = `0.325` and lambda = `0.4568197`, RSquared = `0.9734756` and MAE = `1.436229`.
 
## Visualization 

### Model 1
![](Week13-markdown_files/figure-latex/unnamed-chunk-4-1.pdf)<!-- --> 

### Model 2
![](Week13-markdown_files/figure-latex/unnamed-chunk-5-1.pdf)<!-- --> 

### Visual representation of the relationship between different variables and the final rating 

![](Week13-markdown_files/figure-latex/unnamed-chunk-6-1.pdf)<!-- --> ![](Week13-markdown_files/figure-latex/unnamed-chunk-6-2.pdf)<!-- --> ![](Week13-markdown_files/figure-latex/unnamed-chunk-6-3.pdf)<!-- --> ![](Week13-markdown_files/figure-latex/unnamed-chunk-6-4.pdf)<!-- --> 

## Comparing the Models

```
## 
## Call:
## summary.resamples(object = resamples(list(model1, model2)))
## 
## Models: Model1, Model2 
## Number of resamples: 5 
## 
## MAE 
##             Min.  1st Qu.   Median     Mean  3rd Qu.     Max. NA's
## Model1 3.2395427 3.314094 3.369463 3.908986 3.602473 6.019359    0
## Model2 0.9183604 1.215311 1.292847 1.373753 1.622089 1.820155    0
## 
## RMSE 
##            Min.  1st Qu.   Median     Mean  3rd Qu.     Max. NA's
## Model1 3.891342 4.157302 4.610412 5.631604 4.735933 10.76303    0
## Model2 1.120732 1.487480 1.636099 1.952082 2.733219  2.78288    0
## 
## Rsquared 
##             Min.   1st Qu.    Median      Mean   3rd Qu.      Max. NA's
## Model1 0.7641315 0.8887218 0.8892641 0.8834319 0.9366145 0.9384276    0
## Model2 0.9557526 0.9880719 0.9904588 0.9848805 0.9944737 0.9956454    0
```

## Choosing a Model
When comparing both models, I would select  Model2 using GLMNET, since it yielded the lowest overall MAE and RMSE, as well as the higherst RSquared. I would also choose glmnet since it penalizes coefficients that are too large, or or too small, balancing out the predictors to obtain a model that can more easily be used in a different sample. 

![]("image.jpg")
