# R Studio API Code 
library(rstudioapi)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Libraries 
library(tidyverse)
library(glmnet)
library(psych)
library(caret)
library(psychTools)
library(GGally)
library(ggplot2)


# Data Import and Cleaning
Data<- read.csv("cereal.csv") %>%
  transmute(name = factor(name), mfr = factor(mfr), type = factor(type), shelf = factor(shelf),
            calories = as.numeric(calories), protein = as.numeric(protein), fat = as.numeric(fat), 
            sodium = as.numeric(sodium), fiber = fiber, carbo = carbo, sugars = as.numeric(sugars), 
            potass = as.numeric(potass),vitamins = as.numeric(vitamins), weight = weight, cups = cups, rating = rating)
summary(Data)
str(Data)


# Data Analysis 
# My dataset is composed of 77 types of cereal, their nutrition facts, and their overall rating. 
# I am using the rating variable as my DV and all other variables relating to
# nutrition as predictors of that rating.

train.control <- trainControl(method = "cv", number= 5, verboseIter = T)

## Model1 - Random Forest
model1 <- train(
  rating~., 
  data = Data, 
  method = "ranger", tuneLength = 5, trControl = train.control)  

# Print Model
model1
# Summary of model
summary(model1)

# Results:
# RMSE was used to select the optimal model using the smallest value, RMSE =  5.664539, 
# Rsquared = 0.8683427 and MAE =  3.990460.

     
## Model2 - GLMNET
model2 <- train(
  rating~., 
  data = Data, 
  method = "glmnet", tuneLength = 5, trControl = train.control)  

# Print Model
model2
# Summary of model
summary(model2)

# Results: 
## RMSE was used to select the optimal model using the smallest value.
## The final values used for the model were alpha = 0.325 and lambda = 0.4568197
## RSquared = 0.9734756 and MAE = 1.436229.


# Visualization
ggplot(model1)
ggplot(model2)

## Visual of the relationship between rating and amount of sugar 
ggplot(Data, aes(x=sugars, y=rating))+
  geom_point()+
  geom_smooth(method = "lm", se = T)+
  theme_classic()
## Visual of th relationship between rating and amount of calories
ggplot(Data, aes(x=calories, y=rating))+
  geom_point()+
  geom_smooth(method = "lm", se = T)+
  theme_classic()
## Visual of the relationship between rating and amount of carbohidrates
ggplot(Data, aes(x=carbo, y=rating))+
  geom_point()+
  geom_smooth(method = "lm", se = T)+
  theme_classic()
## Visual of the relationship between between rating and amount of protein
ggplot(Data, aes(x=protein, y=rating))+
  geom_point()+
  geom_smooth(method = "lm", se = T)+
  theme_classic()

# Comparing models
summary(resamples(list(model1, model2)))

## Choosing a model! 
# When comparing both models, I would select  Model2 using GLMNET, since it yielded the lowest overall
  # MAE and RMSE, as well as the higherst RSquared. I would also choose glmnet since it penalizes coefficients
  # that are too large, or or too small, balancing out the predictors to obtain a model that can more easily be 
  # used in a different sample. 